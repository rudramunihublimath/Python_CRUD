from django.shortcuts import render,redirect
from .forms import EmpForm
from .models import Emp


def emp_list(request):
    context = {'employee_list': Emp.objects.all() }
    return render(request,"EMP_Register/Emp_list.html",context)

def emp_form(request,id=0):
    if request.method == "GET" :
        if id ==0 :
            form1 = EmpForm()
        else:
            emp = Emp.objects.get(pk=id)
            form1 = EmpForm(instance=emp)
        return render(request,"EMP_Register/Emp_form.html",{'form2':form1})
    else:  ## for POST
        if id == 0:  ## NEW POST
            form1 = EmpForm(request.POST)
        else:
            emp = Emp.objects.get(pk=id)   ## fetch from DB for pdate
            form1 = EmpForm(request.POST,instance=emp)
        if form1.is_valid():
                form1.save()
        return redirect('/emp/list')

def emp_delete(request):
    return