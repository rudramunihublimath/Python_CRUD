from django import forms
from .models import Emp

class EmpForm(forms.ModelForm):
    class Meta:
       model = Emp
       #fields = '__all__'
       fields = ('fullname','emp_code','mobile','position')
       labels = {
           'fullname' : 'FULL NAME',
           'emp_code':  'Emp. Code'
       }

    def __init__(self,*args,**kwargs):
        super(EmpForm,self).__init__(*args,**kwargs)
        self.fields['position'].empty_label = "Select"  ### default value is Select value
        self.fields['emp_code'].required =False   ### make emp_code as optional