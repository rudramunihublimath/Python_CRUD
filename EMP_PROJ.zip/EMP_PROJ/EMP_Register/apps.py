from django.apps import AppConfig


class EmpRegisterConfig(AppConfig):
    name = 'EMP_Register'
